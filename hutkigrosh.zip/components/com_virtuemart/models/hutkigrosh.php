<?php
/*
* @info     Платёжный модуль bgpb для JoomShopping
* @package  bgpb
* @author   esas.by
* @license  GNU/GPL
*/

use esas\cmsgate\virtuemart\CmsgateModel;

defined('_JEXEC') or die();

class VirtueMartModelHutkigrosh extends CmsgateModel
{


}