<?php

use esas\cmsgate\virtuemart\CmsgateModelVirtuemart;

defined('_JEXEC') or die();

/**
 * Наличие файла с таким именем и классом обязательно для подгрузки модели ядром joomla
 * Class VirtueMartModelHutkigrosh
 */
class VirtueMartModelHutkigrosh extends CmsgateModelVirtuemart
{
}