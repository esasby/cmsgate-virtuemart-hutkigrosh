<?php
/**
 * Скрытое поле кэша метаданных API hutkigrosh (VirtueMart).
 *
 * Хранит полученные кнопкой «Актуализировать» списки услуг/торговых точек/кассовых мест.
 * В БД значение лежит как JSON-объект (VirtueMart сам json_decode-ит параметры при загрузке,
 * поэтому в $this->value может прийти массив/объект). В форму всегда отдаём base64url-строку —
 * это безопасно для HTML-атрибута value (нет кавычек/скобок).
 *
 * Преобразование при рендере (LOAD): array|object|JSON-строка -> base64url.
 * Обратное преобразование при сохранении (base64url -> array) — в plgVmSetOnTablePayment,
 * чтобы в БД ушёл читаемый JSON.
 *
 * ВАЖНО: $this->hidden намеренно НЕ переопределяется (остаётся false), иначе
 * VirtueMart (fields/formrenderer.php) пропустит поле как скрытое и не выведет его.
 */
defined('_JEXEC') or die;

jimport('joomla.form.formfield');

class JFormFieldHgcache extends JFormField
{
	protected $type = 'Hgcache';

	/**
	 * base64url-кодирование (UTF-safe).
	 */
	private static function b64urlEncode($s)
	{
		return rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
	}

	protected function getInput()
	{
		$v = $this->value;
		$out = '';

		if (is_array($v) || is_object($v)) {
			// VirtueMart json_decode-нул JSON из БД -> пришёл массив/объект.
			$out = self::b64urlEncode(json_encode($v, JSON_UNESCAPED_UNICODE));
		} elseif (is_string($v)) {
			$t = trim($v);
			if ($t !== '') {
				// Если в БД почему-то лежал JSON-текст (не декодировался) — кодируем его.
				// Иначе считаем, что это уже base64url (например, пришёл из POST).
				$out = ($t[0] === '{' || $t[0] === '[')
					? self::b64urlEncode($t)
					: $t;
			}
		}

		return '<input type="hidden" name="' . $this->name . '" value="'
			. htmlspecialchars($out, ENT_QUOTES, 'UTF-8') . '" />';
	}
}
