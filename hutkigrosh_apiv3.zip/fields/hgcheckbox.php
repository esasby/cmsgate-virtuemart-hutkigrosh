<?php
/**
 * Кастомное поле формы для настроек плагина hutkigrosh (VirtueMart).
 *
 * Решает проблему сохранения снятых чекбоксов: стандартный HTML checkbox при снятии
 * не отправляется в POST, из-за чего VirtueMart не может записать состояние «выключено».
 *
 * Поле рендерит ДВА input с одинаковым именем:
 *   1) <input type="hidden" value="0">  — всегда отправляется (гарантирует запись «0» при снятом чекбоксе);
 *   2) <input type="checkbox" value="1"> — отправляется только если отмечен.
 *
 * В DOM скрытое поле идёт ПЕРЕД чекбоксом, поэтому при отмеченном состоянии PHP
 * берёт последнее значение (1), а при снятом — остаётся только 0.
 *
 * ВАЖНО: $this->hidden намеренно НЕ переопределяется (остаётся false), иначе
 * VirtueMart (fields/formrenderer.php) пропустит поле как скрытое и не выведет его.
 */
defined('_JEXEC') or die;

jimport('joomla.form.formfield');

class JFormFieldHgcheckbox extends JFormField
{
	/**
	 * Тип поля (совпадает с type="Hgcheckbox" в XML плагина).
	 *
	 * @var    string
	 */
	protected $type = 'Hgcheckbox';

	/**
	 * Возвращает разметку поля: скрытый input + чекбокс.
	 *
	 * @return  string
	 */
	protected function getInput()
	{
		// Текущее состояние: если значение ещё не сохранено (новый метод оплаты),
		// используем default из XML; иначе — сохранённое значение.
		$val = (string) $this->value;
		if ($val === '' || $val === null)
		{
			$val = (string) $this->default;
		}

		$checked  = ($val === '1' || $val === 'true') ? ' checked' : '';
		$class    = !empty($this->class) ? ' class="' . htmlspecialchars($this->class, ENT_COMPAT, 'UTF-8') . '"' : '';
		$disabled = $this->disabled ? ' disabled' : '';
		$onclick  = !empty($this->onclick) ? ' onclick="' . htmlspecialchars($this->onclick, ENT_COMPAT, 'UTF-8') . '"' : '';

		// Скрытое поле с тем же именем идёт ПЕРЕД чекбоксом (см. комментарий к классу).
		return '<input type="hidden" name="' . $this->name . '" value="0" />'
			. '<input type="checkbox" name="' . $this->name . '" value="1"' . $class . $checked . $disabled . $onclick . ' />';
	}
}
