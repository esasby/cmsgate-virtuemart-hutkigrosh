<?php

use apiv3\cmsgate\CmsConnectorVirtuemart;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAddBill;
use apiv3\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use apiv3\cmsgate\Registry;
use Joomla\CMS\Factory;
use Joomla\CMS\Uri\Uri;

defined('_JEXEC') or die;

if (!class_exists('vmPSPlugin')) {
    require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');
}
require_once(dirname(__FILE__) . '/init.php');

class plgVMPaymentHutkigrosh extends vmPSPlugin
{
    function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);
        $this->_tablepkey = 'if';
        $this->_tableId = 'id';
        $varsToPush = $this->getVarsToPush();
        $this->setConfigParameterable($this->_configTableFieldName, $varsToPush);

        // Регистрируем путь к кастомному полю Hgcheckbox (скрытый 0 + чекбокс 1).
        // VirtueMart сам регистрирует только свою папку (VMPATH_ADMIN/fields), поэтому путь
        // к полям плагина добавляем в конструкторе: он вызывается при importVMPlugins('vmpayment')
        // внутри getPayment(), т.е. ДО JForm::getInstance, который строит форму настроек.
        jimport('joomla.form.form');
        JForm::addFieldPath(dirname(__FILE__) . '/fields');
    }

    //+
    function getTableSQLFields()
    {
        $SQLfields = array(
            'id' => 'int(1) UNSIGNED NOT NULL AUTO_INCREMENT', //к сожалению, обязательное поле virtuemart/administrator/components/com_virtuemart/plugins/vmplugin.php:488
            'virtuemart_order_id' => 'int(1) UNSIGNED',
            'ext_trx_id' => 'char(64)'
        );
        return $SQLfields;
    }

    /**
     * Инжектит JS для кнопки "Актуализировать" на странице редактирования способа оплаты в админке VirtueMart.
     * Кнопка запрашивает по apiToken метаданные поставщика услуг и заполняет списки
     * услуг/торговых точек/кассовых мест. Сам JS срабатывает только если на странице присутствует поле api_token.
     */
    public function onBeforeCompileHead()
    {
        $app = Factory::getApplication();
        if (!$app->isClient('administrator'))
            return;
        if ($app->input->getCmd('option') !== 'com_virtuemart' || $app->input->getCmd('task') !== 'edit')
            return;

        $metadataUrl = Uri::root() . 'index.php?option=com_virtuemart&view=hutkigrosh&task=metadata';
        $doc = Factory::getDocument();
        $doc->addScriptDeclaration(<<<JS
document.addEventListener('DOMContentLoaded', function() {
    var tokenInput = document.querySelector('input[name*="api_token"]');
    if (!tokenInput) return; // на странице нет настроек hutkigrosh
    var form = tokenInput.closest('form') || document;

    // base64url (UTF-safe) для скрытого поля кэша метаданных API.
    function b64urlEncode(str) {
        return btoa(unescape(encodeURIComponent(str))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    }
    function b64urlDecode(str) {
        return decodeURIComponent(escape(atob(str.replace(/-/g, '+').replace(/_/g, '/'))));
    }

    // Скрытое поле кэша (base64url JSON). Прячем его видимую строку-обертку в админке.
    var cacheInput = form.querySelector('input[name*="hg_cache"]');
    if (cacheInput) {
        var cacheRow = cacheInput.closest('tr, .control-group, .form-group');
        if (cacheRow) cacheRow.style.display = 'none';
    }

    // Реальные значения хранятся в текстовых полях (VirtueMart сохраняет их надежно).
    // Поверх каждого текстового поля строится выпадающий список (без name — не отправляется на сервер).
    function textField(key) { return form.querySelector('input[name*="' + key + '"]'); }
    var svcText = textField('service_id');
    var outText = textField('retail_outlet_id');
    var cashText = textField('cash_box_id');

    function buildSelect(textEl) {
        if (!textEl) return null;
        var sel = document.createElement('select');
        sel.className = textEl.className || 'inputbox';
        sel.innerHTML = '<option value=""></option>';
        textEl.type = 'hidden'; // скрываем, но поле остается в форме и сохраняется
        if (textEl.parentNode) textEl.parentNode.appendChild(sel);
        sel.addEventListener('change', function() { textEl.value = sel.value; });
        return sel;
    }

    var svcSel = buildSelect(svcText);
    var outSel = buildSelect(outText);
    var cashSel = buildSelect(cashText);

    var refreshBtn = document.createElement('button');
    refreshBtn.type = 'button';
    refreshBtn.className = 'btn btn-primary';
    refreshBtn.style.marginLeft = '10px';
    refreshBtn.innerHTML = 'Актуализировать';
    tokenInput.parentNode.appendChild(refreshBtn);

    var globalData = null;

    function renderOptions(sel, items, selectedCode) {
        if (!sel) return;
        var html = '';
        if (items && items.length > 0) {
            items.forEach(function(item) {
                var val = item.code !== undefined ? item.code : item.id;
                var s = (String(val) === String(selectedCode)) ? ' selected' : '';
                html += '<option value="' + val + '"' + s + '>' + item.name + '</option>';
            });
        } else {
            html = '<option value="">Нет данных</option>';
        }
        sel.innerHTML = html;
    }

    function cashBoxesFor(outletCode) {
        if (!globalData || !globalData.retailOutlets) return [];
        var o = globalData.retailOutlets.find(function(x) { return String(x.code) === String(outletCode); });
        if (!o && globalData.retailOutlets.length) o = globalData.retailOutlets[0];
        return o ? (o.cashBoxes || []) : [];
    }

    function applyData(data) {
        globalData = data;
        renderOptions(svcSel, data.services, svcText ? svcText.value : '');
        renderOptions(outSel, data.retailOutlets, outText ? outText.value : '');
        renderOptions(cashSel, cashBoxesFor(outText ? outText.value : ''), cashText ? cashText.value : '');
        [svcSel, outSel, cashSel].forEach(function(s) { if (s) s.disabled = false; });
    }

    function showNoData() {
        [svcSel, outSel, cashSel].forEach(function(s) {
            if (!s) return;
            s.disabled = false;
            s.innerHTML = '<option value="">Нет данных</option>';
        });
    }

    // При смене торговой точки обновляем список кассовых мест и синхронизируем скрытое поле
    if (outSel) {
        outSel.addEventListener('change', function() {
            if (outText) outText.value = outSel.value;
            renderOptions(cashSel, cashBoxesFor(outSel.value), cashText ? cashText.value : '');
        });
    }

    // Текущее состояние переключателя Sandbox (radio). Чтобы запрос метаданных шел на тот же сервер
    // (test/prod), что выбран в форме ДО сохранения настроек — передаем его в эндпоинт metadata.
    // Возвращает null, если переключатель на странице не найден (тогда параметр не добавляем).
    function getSandbox() {
        var checked = form.querySelector('input[name*="sandbox"]:checked');
        return checked ? checked.value : null;
    }

    function doRefresh(showAlert) {
        var token = (tokenInput.value || '').trim();
        if (!token) { if (showAlert) alert('Сначала введите API Token'); return; }
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = 'Загрузка...';
        [svcSel, outSel, cashSel].forEach(function(s) { if (s) { s.disabled = true; s.innerHTML = '<option>Загрузка...</option>'; } });

        var xhr = new XMLHttpRequest();
        var url = '$metadataUrl&api_token=' + encodeURIComponent(token);
        var sb = getSandbox();
        if (sb !== null) url += '&sandbox=' + encodeURIComponent(sb);
        xhr.open('GET', url, true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.onload = function() {
            var data = null;
            try { data = JSON.parse(xhr.responseText); } catch (e) {}
            if (xhr.status === 200 && data && typeof data.message === 'undefined') {
                applyData(data);
                // кэшируем метаданные в скрытом поле (base64url), чтобы при перезагрузке не запрашивать API
                if (cacheInput) cacheInput.value = b64urlEncode(JSON.stringify(data));
            } else {
                if (showAlert) {
                    var msg = (data && data.message) ? data.message : ('HTTP ' + xhr.status);
                    alert('Ошибка API или неверный токен. ' + msg);
                }
                showNoData();
            }
        };
        xhr.onerror = function() { if (showAlert) alert('Ошибка соединения с сервером'); showNoData(); };
        xhr.onloadend = function() { refreshBtn.disabled = false; refreshBtn.innerHTML = 'Актуализировать'; };
        xhr.send();
    }

    refreshBtn.addEventListener('click', function() { doRefresh(true); });

    // При загрузке страницы восстанавливаем селекты ИЗ КЭША (без запроса к API).
    // До первого «Актуализировать» (кэш пуст) селекты остаются пустыми.
    if (cacheInput && (cacheInput.value || '').trim()) {
        try {
            var cached = JSON.parse(b64urlDecode(cacheInput.value.trim()));
            if (cached && typeof cached.message === 'undefined') applyData(cached);
        } catch (e) {}
    }
});
JS
        );
    }

    function plgVmConfirmedOrder($cart, $order)
    {
        // VirtueMart вызывает plgVmConfirmedOrder у ВСЕХ опубликованных vmpayment-плагинов.
        // Обязательный guard: отсекаем чужие заказы, иначе этот плагин создаст счёт в ХуткiГрош
        // для заказа, оформленного через другой платёжный метод (напр. epos).
        if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
            return null; // выбран другой способ оплаты — ничего не делаем
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return false;
        }
        $orderWrapper = Registry::getRegistry()->getOrderWrapper($order['details']['BT']->virtuemart_order_id);
        $controller = new ControllerHutkigroshAddBill();
        $resp = $controller->process($orderWrapper);
        if ($resp->hasError())
            return false;

        if (!class_exists('VirtueMartCart'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
        $cart = VirtueMartCart::getCart();
        $cart->emptyCart();
        /**
         * На этом этапе мы только выполняем запрос к HG для добавления счета. Мы не показываем итоговый экран
         * (с кнопкой webpay), а выполняем автоматический редирект на страницу complete.
         **/
        $redirectParams = array(
            RequestParamsHutkigrosh::BILL_ID => $resp->getBillId(),
            RequestParamsHutkigrosh::ORDER_NUMBER => $orderWrapper->getOrderNumber());
        Factory::getApplication()->redirect(CmsConnectorVirtuemart::generatePaySystemControllerPath("complete") . '&' . http_build_query($redirectParams));
    }

    function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id)
    {
        if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
            return NULL;
        }

        if (!($paymentTable = $this->getDataByOrderId($virtuemart_order_id))) {
            return NULL;
        }
        VmConfig::loadJLang('com_virtuemart');

        $html = '<table class="adminlist table">' . "\n";
        $html .= $this->getHtmlHeaderBE();
        $html .= $this->getHtmlRowBE('COM_VIRTUEMART_PAYMENT_NAME', $paymentTable->payment_name);
        $html .= $this->getHtmlRowBE('STANDARD_PAYMENT_TOTAL_CURRENCY', $paymentTable->payment_order_total . ' ' . $paymentTable->payment_currency);
        if ($paymentTable->email_currency) {
            $html .= $this->getHtmlRowBE('STANDARD_EMAIL_CURRENCY', $paymentTable->email_currency);
        }
        $html .= '</table>' . "\n";
        return $html;
    }

    function checkConditions($cart, $method, $cart_prices)
    {
        //todo check configuration
        return true;
    }

    //+
    function plgVmOnStoreInstallPaymentPluginTable($jplugin_id)
    {
        return $this->onStoreInstallPluginTable($jplugin_id);
    }

    //+
    public function plgVmOnSelectCheckPayment(VirtueMartCart $cart, &$msg)
    {
        return $this->OnSelectCheck($cart);
    }

    //+
    public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
    {
        //todo добавить надпись про sandbox
        return $this->displayListFE($cart, $selected, $htmlIn);
    }

    //+
    public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
    {
        return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
    }

    function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId)
    {
        if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
            return NULL;
        }
        if (!$this->selectedThisElement($method->payment_element)) {
            return FALSE;
        }
        $this->getPaymentCurrency($method);

        $paymentCurrencyId = $method->payment_currency;
        return;
    }

    //+
    function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array(), &$paymentCounter)
    {
        return $this->onCheckAutomaticSelected($cart, $cart_prices, $paymentCounter);
    }

    //+
    public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name)
    {
        $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
    }

    //+
    public function plgVmOnCheckoutCheckDataPayment(VirtueMartCart $cart)
    {
        return null;
    }

    function plgVmonShowOrderPrintPayment($order_number, $method_id)
    {
        return $this->onShowOrderPrint($order_number, $method_id);
    }

    //+
    function plgVmDeclarePluginParamsPaymentVM3(&$data)
    {
        return $this->declarePluginParams('payment', $data);
    }

    //*
    function plgVmSetOnTablePluginParamsPayment($name, $id, &$table)
    {
        return $this->setOnTablePluginParams($name, $id, $table);
    }

    /**
     * Срабатывает перед упаковкой параметров в payment_params (после plgVmSetOnTablePluginParamsPayment,
     * до bindChecknStore). Декодируем кэш метаданных hg_cache из base64url в массив — тогда VirtueMart
     * в storeParams() сохранит его в БД как читаемый JSON-объект, а не как base64-строку.
     */
    function plgVmSetOnTablePayment(&$data, &$table)
    {
        $paths = array(array('params', 'hg_cache'), array('hg_cache'));
        foreach ($paths as $path) {
            $ref = &$data;
            $ok = true;
            foreach ($path as $seg) {
                if (is_array($ref) && array_key_exists($seg, $ref)) {
                    $ref = &$ref[$seg];
                } else {
                    $ok = false;
                    break;
                }
            }
            if ($ok && is_string($ref) && $ref !== '') {
                $decoded = json_decode(base64_decode(strtr($ref, '-_', '+/')), true);
                if (is_array($decoded)) {
                    $ref = $decoded;
                }
            }
        }
    }

    //+ может не надо чистить карту?
    function plgVmOnPaymentResponseReceived(&$html)
    {
        if (!class_exists('VirtueMartCart'))
            require(JPATH_VM_SITE . DS . 'helpers' . DS . 'cart.php');
        $cart = VirtueMartCart::getCart();
        $cart->emptyCart();
        return true;
    }

    function plgVmOnUserPaymentCancel()
    {
        if (!class_exists('VirtueMartModelOrders'))
            require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');

        $order_number = vRequest::getVar('on');
        if (!$order_number)
            return false;
        $db = JFactory::getDBO();
        $query = 'SELECT ' . $this->_tablename . '.`virtuemart_order_id` FROM ' . $this->_tablename . " WHERE  `order_number`= '" . $order_number . "'";

        $db->setQuery($query);
        $virtuemart_order_id = $db->loadResult();

        if (!$virtuemart_order_id) {
            return null;
        }
        $this->handlePaymentUserCancel($virtuemart_order_id);

        return true;
    }
}
