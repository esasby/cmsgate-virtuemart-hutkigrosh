<?php
// hutkigrosh изолирован собственным namespace apiv3\cmsgate (а не общим базовым namespace,
// как плагин epos), чтобы избежать конфликта повторного объявления класса CmsPlugin.
// Guard дополнительно страхует от повторного объявления при гипотетическом втором apiv3-плагине.
if (!class_exists('apiv3\cmsgate\CmsPlugin'))
    require_once(dirname(__FILE__) . '/vendor/apiv3/cmsgate-core/src/apiv3/cmsgate/CmsPlugin.php');
use apiv3\cmsgate\CmsPlugin;
use apiv3\cmsgate\hutkigrosh\RegistryHutkigroshVirtuemart;


(new CmsPlugin(dirname(__FILE__) . '/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshVirtuemart())
    ->init();
