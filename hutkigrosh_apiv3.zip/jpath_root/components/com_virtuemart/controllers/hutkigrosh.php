<?php

/**
 *
 * Controller for the Plugins Response
 *
 * @package	VirtueMart
 * @subpackage pluginResponse
 * @author Valérie Isaksen
 * @link https://virtuemart.net
 * @copyright Copyright (c) 2004 - 2014 VirtueMart Team and authors. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * @version $Id: cart.php 3388 2011-05-27 13:50:18Z alatak $
 */
// Check to ensure this file is included in Joomla!
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshCompletionPage;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshNotify;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshRq;
use apiv3\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh;
use apiv3\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use apiv3\cmsgate\Registry;
use apiv3\cmsgate\utils\Logger;
use Joomla\CMS\Factory;

defined('_JEXEC') or die('Restricted access');

// Load the controller framework
jimport('joomla.application.component.controller');
require_once(dirname(dirname(dirname(dirname(__FILE__)))) . '/plugins/vmpayment/hutkigrosh/init.php');

/**
 * Controller for the plugin response view
 *
 * @package VirtueMart
 * @subpackage pluginresponse
 * @author Valérie Isaksen
 *
 */
class VirtueMartControllerHutkigrosh extends JControllerLegacy {

    /**
     * Construct the cart
     *
     * @access public
     */
    public function __construct() {
		parent::__construct();
    }

    function complete()
    {
        try {
            $orderNumber = vRequest::getVar(RequestParamsHutkigrosh::ORDER_NUMBER);
            $billId = vRequest::getVar(RequestParamsHutkigrosh::BILL_ID);
            // Заказ ищем по order_number, при его отсутствии — по bill_id (сервис ХГ
            // возвращает покупателя ссылкой только с bill_id).
            $orderWrapper = null;
            if (!empty($orderNumber))
                $orderWrapper = Registry::getRegistry()->getOrderWrapperByOrderNumber($orderNumber);
            if (empty($orderWrapper) && !empty($billId))
                $orderWrapper = Registry::getRegistry()->getOrderWrapperByExtId($billId);
            if (empty($orderWrapper))
                throw new Exception("Incorrect order");
            $user = Factory::getUser();
            // Гостевые заказы (clientId == 0) открываем по order_number/bill_id (выступают токеном).
            // Для заказов зарегистрированных пользователей — только владелец.
            if ($orderWrapper->getClientId() != 0 && $user->id != $orderWrapper->getClientId()) {
                throw new Exception("Incorrect order number");
            }
            // При наличии bill_id — актуализируем статус счёта на шлюзе и обновляем локальный
            // заказ (та же логика, что и в notify): apiBillInfo → смена статуса заказа в БД.
            if (!empty($billId)) {
                $notifyController = new ControllerHutkigroshNotify();
                $notifyController->process($billId);
                // Перезагружаем заказ — notify мог изменить его статус в БД.
                $orderWrapper = Registry::getRegistry()->getOrderWrapper($orderWrapper->getOrderId());
            }
            $controller = new ControllerHutkigroshCompletionPage();
            $completionPanel = $controller->process($orderWrapper);
            $completionPanel->render();
        } catch (Throwable $e) {
            Logger::getLogger("payment")->error("Exception:", $e);
            JFactory::getApplication()->enqueueMessage($e->getMessage(), 'error');
        }
    }

    /**
     * AJAX-эндпоинт для кнопки "Актуализировать" в настройках плагина.
     * По переданному api_token запрашивает метаданные поставщика услуг (service-provider/metadata)
     * и возвращает JSON со списками services/retailOutlets/cashBoxes для заполнения select-полей настроек.
     * Токен применяется только в рамках данного запроса (через временный override), в БД не сохраняется.
     */
    function metadata()
    {
        header('Content-Type: application/json; charset=utf-8', true);
        try {
            $apiToken = vRequest::getVar(RequestParamsHutkigrosh::API_TOKEN, '', 'string');
            // Подменяем apiToken на время запроса, чтобы HutkigroshProtocol подписал им запрос.
            ConfigWrapperHutkigrosh::setApiTokenOverride($apiToken);
            // Подменяем режим песочницы на время запроса: сервер (test/prod) должен совпадать с тем,
            // что сейчас выбран переключателем Sandbox в форме, а не тем, что сохранено в БД.
            // Иначе до сохранения настроек актуализация шла бы не на тот сервер.
            $sandbox = vRequest::getVar(RequestParamsHutkigrosh::SANDBOX, null);
            ConfigWrapperHutkigrosh::setSandboxOverride($sandbox);
            $hg = new HutkigroshProtocol(ConfigWrapperHutkigrosh::fromRegistry());
            $hg->checkProviderMetadata(new HutkigroshRq());
            echo json_encode($hg->rqProviderMetadata);
        } catch (Throwable $e) {
            Logger::getLogger("callback")->error("metadata Exception:", $e);
            echo json_encode(array('message' => $e->getMessage()));
        }
        JFactory::getApplication()->close();
    }


    /**
     * Callback, который вызывает сам ХуткиГрош для оповещение об оплате счета в ЕРИП
     * Тут выполняется дополнительная проверка статуса счета на шлюза и при необходимости изменение его статус заказа
     * в локальной БД
     */
    function notify()
    {
        // Эндпоинт вызывается самим ХуткiГрош (POST) при оплате счета. Должен отвечать JSON
        // и НЕ рендерить страницу (иначе Joomla/VM продолжают обычный флоу контроллера).
        header('Content-Type: application/json; charset=utf-8', true);
        try {
            $controller = new ControllerHutkigroshNotify();
            $billInfoRs = $controller->process();
            echo json_encode(array(
                'result' => ($billInfoRs && !$billInfoRs->hasError()) ? 'ok' : 'error',
                'status' => $billInfoRs ? $billInfoRs->getStatus() : null,
            ));
        } catch (Throwable $e) {
            Logger::getLogger("callback")->error("Exception:", $e);
            echo json_encode(array('result' => 'error', 'message' => $e->getMessage()));
        }
        JFactory::getApplication()->close();
    }
}
